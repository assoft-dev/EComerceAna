﻿namespace DataEntity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("Factura")]
    public class FacturaModels
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int FacturaModelsID { get; set; }

        [Key]
        public string NumeroFactura { get; set; }
        public DateTime DataHora { get; set; }
        public decimal ValorTotal { get; set; }
        public virtual ICollection<FacturaOrdemModels> FacturaOrdemModels { get; set; }
    }
}
